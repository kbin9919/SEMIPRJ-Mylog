const searchProfile = $(".search-profile");
searchProfile.on('click', function(){
	
});

const searchBoard = $(".board");
searchBoard.on('click', function(){
	
});
